// ==UserScript==
// @name         Widescreen Praktomat
// @namespace    http://your-namespace.example.com
// @version      1.0
// @description  Allows the Praktomat to fully utilize the available screenspace
// @match        https://praktomat-emden.de/*
// @grant        none
// @author       Aderyn Crow
// ==/UserScript==
(function() {
    'use strict';

    // Add a delay to ensure the page is fully loaded
    setTimeout(function() {
        // Find the anchor element with the onclick attribute
        var triggerElement = document.querySelector('a[onclick="toggleMaxWidth()"]');
        if (triggerElement) {
            triggerElement.click();
        }
    }, 0); // Adjust the delay as needed
})();